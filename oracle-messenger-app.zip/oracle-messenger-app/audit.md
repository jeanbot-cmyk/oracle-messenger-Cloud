# Audit technique — Oracle Messenger
*Rédigé par Claude (Anthropic), l'auteur du code. Objectif : donner une vision
honnête de ce qui est solide, ce qui est fragile, et ce qui est absent, avant
tout lancement réel.*

---

## 1. Ce qui fonctionne réellement (testé/vérifié dans cet environnement)

- Le code est syntaxiquement valide (accolades/parenthèses équilibrées,
  aucune déclaration dupliquée) — vérifié par script, mais **jamais compilé
  avec un vrai `npm run build`**, faute d'accès réseau dans cet environnement
  de développement pour installer les dépendances.
- L'architecture React (hooks, composition de composants) est cohérente et
  suit les pratiques standards de Next.js App Router.
- Le découpage en fichiers (`src/lib/*.js` pour la logique métier, séparée
  de l'interface) suit une bonne pratique de base.

## 2. Ce qui est réel mais NON TESTÉ en conditions réelles

Tout ce qui suit a été écrit selon les standards officiels (Firebase,
WebRTC, Paystack) mais **je n'ai eu accès à aucun vrai téléphone, aucun
vrai compte Firebase actif, aucune vraie clé Paystack** pour le valider :

- **Authentification téléphone (Firebase Auth)** — code correct sur le papier ;
  premier vrai test à faire une fois déployé sur un domaine autorisé.
- **Messagerie temps réel (Firestore)** — la logique d'envoi/écoute est
  standard, mais n'a jamais vu passer un vrai message entre deux appareils.
- **Appels WebRTC** — c'est la partie la plus fragile de tout le projet.
  WebRTC est notoirement difficile à faire fonctionner de façon fiable
  (NAT traversal, pare-feu, réseaux mobiles restrictifs) ; le code présent
  n'inclut PAS de serveur TURN (seulement des serveurs STUN publics Google),
  ce qui veut dire que **les appels échoueront probablement dès que les deux
  personnes ne sont pas sur le même réseau ou un réseau ouvert**. Un serveur
  TURN (ex: via Twilio, ou coturn auto-hébergé) sera presque certainement
  nécessaire.
- **Notifications push (Firebase Cloud Messaging)** — code client + Cloud
  Function écrits, mais jamais déployés ni déclenchés réellement.

## 3. Failles de sécurité identifiées — à corriger AVANT tout lancement

### 🔴 Critique : règles Firestore par défaut
Un projet Firebase nouvellement créé a des règles Firestore qui, selon la
configuration choisie à la création, peuvent autoriser **n'importe qui sur
Internet à lire ou écrire dans toute la base de données**, pas seulement
les utilisateurs de l'app. Il faut vérifier et restreindre les règles
(Firebase Console → Firestore → Rules) avant tout lancement, par exemple
en n'autorisant un utilisateur qu'à lire/écrire les conversations dont il
est membre.

### 🔴 Critique : vérification de paiement côté client uniquement
Dans le code actuel, quand Paystack renvoie un succès, c'est le
**navigateur de l'utilisateur** qui décide localement "paiement réussi,
je débloque le Hub Business". Un utilisateur un peu technique pourrait
falsifier ça sans payer. **La fonction `verifyPaystackPayment` dans
`functions/index.js` corrige ce problème** en vérifiant la transaction
côté serveur — mais il faut la déployer et modifier le frontend pour
l'appeler, ce qui n'est pas encore fait dans `ScreenDon`/`ScreenBusinessHub`.

### 🟠 Important : mot de passe root partagé en clair
Signalé plus tôt dans la conversation — si ce n'est pas encore fait,
**change le mot de passe root de ton VPS immédiatement**.

### 🟠 Important : une seule conversation partagée pour tous
Actuellement, TOUS les utilisateurs de l'app, une fois déployée, verraient
et écriraient dans la **même** conversation Firestore (`demo-conversation`)
— ce n'est pas un vrai système multi-utilisateurs. Il faut construire un
vrai annuaire de contacts qui génère un identifiant de conversation unique
par paire d'utilisateurs (la fonction `conversationIdFor()` dans
`messaging.js` existe déjà pour ça, mais n'est pas encore appelée nulle
part dans l'interface).

### 🟡 À surveiller : clé API exposée dans le service worker
Le fichier `public/firebase-messaging-sw.js` contient la config Firebase
en clair — c'est normal et sans danger (ce sont des clés publiques), mais
assure-toi de ne jamais y coller une clé secrète par erreur.

## 4. Fonctionnalités du cahier des charges encore absentes

- Transfert P2P réel de fichiers volumineux (WebRTC DataChannel) — les
  photos/vidéos envoyées dans le chat restent locales au navigateur
- Chiffrement de bout en bout des messages (mentionné dans le cahier des
  charges, pas implémenté — Firestore stocke actuellement le texte en clair)
- Retouche photo/vidéo réelle (l'interface existe, les filtres CSS sont
  cosmétiques, pas d'export d'image modifiée)
- CRM, envois massifs, automatisation par mots-clés : interface complète,
  aucune logique serveur derrière
- Panel d'administration
- Internationalisation (multilingue)
- Détection deep-linking / liens intelligents Android App Links / iOS
  Universal Links

## 5. Recommandation de priorités avant un premier vrai test utilisateur

1. Restreindre les règles Firestore (sécurité — critique, rapide à faire)
2. Déployer la Cloud Function de vérification de paiement et la brancher
3. Construire l'annuaire de contacts / conversations réelles par paire
4. Tester les appels WebRTC avec deux vrais téléphones sur réseaux
   différents ; si échec, ajouter un serveur TURN
5. Décider d'une stratégie de chiffrement (au minimum HTTPS partout, au
   mieux chiffrement de bout en bout applicatif)

## 6. Verdict global

**Qualité du code pour un prototype avancé : bonne.** Structure lisible,
pas de mauvaises pratiques évidentes, bases techniques correctes.

**Prêt pour un lancement public : non.** Les manques ne sont pas cosmétiques
— sécurité des paiements, règles de base de données, et fiabilité des appels
sont des sujets qui peuvent coûter de l'argent ou casser la confiance des
premiers utilisateurs s'ils ne sont pas traités avant le lancement.

C'est une base de travail sérieuse, pas un produit fini.
